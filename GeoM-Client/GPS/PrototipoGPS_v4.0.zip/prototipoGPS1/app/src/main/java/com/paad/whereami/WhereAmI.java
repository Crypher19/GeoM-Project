package com.paad.whereami;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;

public class WhereAmI extends AppCompatActivity /*implements OnMapReadyCallback */{

    double lat = 0;
    double lon = 0;

  protected boolean isRouteDisplayed() {
    return false;
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.map);

    /*Bundle b = getIntent().getExtras();
    lat = b.getDouble("latitudine");
    lon = b.getDouble("longitudine");*/

      /*SupportMapFragment mapFragment =
              (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapAndroid);
      mapFragment.getMapAsync(this);*/



  }
    /*public void onMapReady(GoogleMap map) {
        TextView myLocationText;
        myLocationText = (TextView)findViewById(R.id.myLocationText);

        String latLongString = "No location found";
        String addressString = "No address found";

        map.addMarker(new MarkerOptions().position(new LatLng(lat, lon)).title("Marker"));
        if (lat != 0 && lon != 0) {
            // Update the position overlay.

            latLongString = "Lat:" + lat + "\nLong:" + lon;

            double latitude = lat;
            double longitude = lon;

            Geocoder gc = new Geocoder(this, Locale.getDefault());

            if (!Geocoder.isPresent())
                addressString = "No geocoder available";
            else {
                try {
                    List<Address> addresses = gc.getFromLocation(latitude, longitude, 1);
                    StringBuilder sb = new StringBuilder();
                    if (addresses.size() > 0) {
                        Address address = addresses.get(0);

                        for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
                            sb.append(address.getAddressLine(i)).append("\n");

                        sb.append(address.getLocality()).append("\n");
                        sb.append(address.getPostalCode()).append("\n");
                        sb.append(address.getCountryName());
                    }
                    addressString = sb.toString();
                } catch (IOException e) {
                    Log.d("WHEREAMI", "IO Exception", e);
                }
            }
        }

        myLocationText.setText("Your Current Position is:\n" +
                latLongString + "\n\n" + addressString);
        if(lat == 59 && lon == 59)
        {
            myLocationText.setText("Povero Aldo Plel!!!");
        }
    }*/
  
  @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
  
	protected void onCreate() {
		
		
      };
	}

