/** Automatically generated file. DO NOT MODIFY */
package com.paad.whereami;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}