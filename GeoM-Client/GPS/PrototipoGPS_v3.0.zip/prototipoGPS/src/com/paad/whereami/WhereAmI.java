package com.paad.whereami;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.annotation.SuppressLint;
import android.location.Address;
import android.location.Geocoder;
import android.util.Log;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

public class WhereAmI extends MapActivity {

  @Override
  protected boolean isRouteDisplayed() {
    return false;
  }

  private MapController mapController;

  private MyPositionOverlay positionOverlay;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    Bundle b = getIntent().getExtras();
    double lat = b.getDouble("latitudine");
    double lon = b.getDouble("longitudine");
    // Get a reference to the MapView
    MapView myMapView = (MapView)findViewById(R.id.myMapView);

    // Get the Map View's controller
    mapController = myMapView.getController();

    // Configure the map display options
    myMapView.setSatellite(true);
    myMapView.setBuiltInZoomControls(true);

    // Zoom in
    mapController.setZoom(17);

    // Add the MyPositionOverlay
    positionOverlay = new MyPositionOverlay();
    List<Overlay> overlays = myMapView.getOverlays();
    overlays.add(positionOverlay);
    myMapView.postInvalidate();
    
    ricercaPosizione(lat,lon); //ricerca la posizione realtiva alle coorinate ricevute dal server

  }

  @SuppressLint("NewApi")
private void ricercaPosizione(double lat, double lon) {
    TextView myLocationText;
    myLocationText = (TextView)findViewById(R.id.myLocationText);
      
    String latLongString = "No location found";
    String addressString = "No address found";
    
    if (lat != 0 && lon != 0) {
      // Update the position overlay.
      positionOverlay.setLocation(lat,lon);
      Double geoLat = lat*1E6;
      Double geoLng = lon*1E6;
      GeoPoint point = new GeoPoint(geoLat.intValue(),
                                    geoLng.intValue());
      mapController.animateTo(point);
      
      latLongString = "Lat:" + lat + "\nLong:" + lon;
      
      double latitude = lat;
      double longitude = lon;
      Geocoder gc = new Geocoder(this, Locale.getDefault());

      if (!Geocoder.isPresent())
        addressString = "No geocoder available";
      else {
        try {
          List<Address> addresses = gc.getFromLocation(latitude, longitude, 1);
          StringBuilder sb = new StringBuilder();
          if (addresses.size() > 0) {
            Address address = addresses.get(0);

            for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
              sb.append(address.getAddressLine(i)).append("\n");

            sb.append(address.getLocality()).append("\n");
            sb.append(address.getPostalCode()).append("\n");
            sb.append(address.getCountryName());
          }
          addressString = sb.toString();
        } catch (IOException e) {
          Log.d("WHEREAMI", "IO Exception", e);
        }
      }
    }
      
    myLocationText.setText("Your Current Position is:\n" +
      latLongString + "\n\n" + addressString);
  }
  
  @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
  
	protected void onCreate() {
		
		
      };
	}

