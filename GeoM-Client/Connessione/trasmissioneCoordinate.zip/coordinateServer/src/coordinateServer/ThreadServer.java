package coordinateServer;
import java.net.Socket;
import java.io.*;

public class ThreadServer extends Thread{
	InputStreamReader inp = new InputStreamReader(System.in);
	BufferedReader tastiera = new BufferedReader(inp);
	private Socket connessione;
	// stream per gestire il flusso in input
	private InputStreamReader in;
	private BufferedReader sIN;
	// stream per gestire il flusso in output
	private OutputStream out;
	private PrintWriter sOUT;

	private String recived;
	private String sent;

	private XMLWriter writer;

	public ThreadServer(Socket connection){
		this.connessione = connection;

		try {
			in = new InputStreamReader(connessione.getInputStream());
			sIN = new BufferedReader(in);
			out = connessione.getOutputStream();
			sOUT = new PrintWriter(out);
		} catch (IOException e) {
			e.printStackTrace();
		}

		writer = new XMLWriter();

		recived = null;
		sent = null;
	}

	@Override
	public void run(){
		try {
			
			System.out.println("Latitudine:");
			String lat= tastiera.readLine();
			
			System.out.println("Longitudine:");
			String lng= tastiera.readLine();
			
			Coordinate c = new Coordinate();
			c.setLat(Double.parseDouble(lat));
			c.setLng(Double.parseDouble(lng));
			
			sOUT.println(recived = writer.toXMLMessage(c));
			sOUT.flush();
			
			//output su console
			System.out.println("MESSAGGIO INVIATO:\n" + sent);

			//chiusura connessione
			sIN.close();
			sOUT.close();
			connessione.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
