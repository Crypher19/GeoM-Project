package coordinateServer;
import java.net.*;
import java.io.*;

public class Server {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket sSocket;
		Socket connessione;
		int porta = 3333;

		ThreadServer user;

		try{
			sSocket = new ServerSocket(porta);
			while (true) {
				System.out.println("In attesa di connessioni...");
				connessione = sSocket.accept();

				System.out.println("Connessione stabilita.");
				//faccio partire il nuovo thread
				user = new ThreadServer(connessione);
				user.start();

				System.out.println("Connessione chiusa.");
			}
		} catch (IOException e) {
			System.err.println(e);
		}
	}

}
