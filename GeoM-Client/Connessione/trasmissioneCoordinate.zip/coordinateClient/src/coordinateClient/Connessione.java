package coordinateClient;
import java.net.*;
import java.io.*;

public class Connessione {
	private Socket connessione;

	private InputStreamReader input;
	private BufferedReader sIN;

	private OutputStream out;
	private PrintWriter sOUT;

	private String server = "localhost";
	private int port = 3333;

	private XMLReader reader;

	private String recived;
	//per il login
	private String nome;
	private String cognome;

	public Connessione(){
		this.server = "localhost";
		this.port = 3333;
		
		reader = new XMLReader();

		recived = null;

		setNome(null);
		setCognome(null);
	}

	public Connessione(String server, int port){
		this.server = server;
		this.port = port;

		reader = new XMLReader();

		recived = null;

		setNome(null);
		setCognome(null);
	}

	public Coordinate richiestaDati(){

		Coordinate c = new Coordinate();
		try {
			
			//connesione al server
			connect();

			//ricevo esito
			recived = sIN.readLine();

			//chiusura canali
			close();
			
			//estrapolo coordinate dal messaggio ricevuto dal server
			
			c.setLat(Double.parseDouble(reader.getElement(recived, "latitudine")));
			c.setLng(Double.parseDouble(reader.getElement(recived, "longitudine")));

			return c;//login errato

		} catch (IOException e) {
			e.printStackTrace();
		}	

		return c;//errore
	}

	private void connect() throws IOException{
		connessione = new Socket(server, port);
		input = new InputStreamReader(connessione.getInputStream());
		sIN = new BufferedReader(input);

		out = connessione.getOutputStream();
		sOUT = new PrintWriter(out);
	}

	private void close() throws IOException{
		sIN.close();
		sOUT.close();
		connessione.close();
	}

	public void setNome(String nome){
		this.nome = nome;
	}

	public void setCognome(String cognome){
		this.cognome = cognome;
	}

	public String getNome(){
		return this.nome;
	}

	public String getCognome(){
		return this.cognome;
	}
}
