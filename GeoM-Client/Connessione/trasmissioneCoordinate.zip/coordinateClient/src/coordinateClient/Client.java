package coordinateClient;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Connessione c = new Connessione();

		try
		{
			Coordinate coord = new Coordinate();
			coord = c.richiestaDati();
			System.out.println(coord.getLat());
			System.out.println(coord.getLng());
			
		}catch(Exception e){
			System.out.println("Errore");
		}
	}

}
