package provaxml;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class provaXML {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		
		//Connessione conn = new Connessione("172.16.102.132", 3333);
		Connessione conn = new Connessione("127.0.0.1", 3333);
		Document doc = conn.toDOCObject("messaggio.xml");
		
		NodeList nodelist;
		
	    // ottengo la lista di tutti gli elementi "username"
		nodelist = doc.getElementsByTagName("tipo"); 
		
		// prendo il primo elemento e modifico il testo in base al valore scelto dall'utente
		nodelist.item(0).setTextContent("user");
		
		conn.sendMessage(doc);
		String msgRicevuto = conn.readMessage();
		System.out.println("Risposta: " + msgRicevuto);
		
		msgRicevuto = conn.readMessage();
		Document doc2 = Connessione.convertStringToDocument(msgRicevuto);
		System.out.println("Risposta: " + msgRicevuto);
		
		conn.sendMessage(conn.toDOCObject("mezzo.xml"));
		msgRicevuto = conn.readMessage();
		Document doc3 = Connessione.convertStringToDocument(msgRicevuto);
		System.out.println("Risposta: " + msgRicevuto);
		
		/*if ("Connected".equals(msgRicevuto)) {
			Document doc2 = conn.toDOCObject("autenticazione.xml");
			
			NodeList username, password;
			
		    // ottengo la lista di tutti gli elementi "username"
			username = doc.getElementsByTagName("username"); 		
			// prendo il primo elemento e modifico il testo in base al valore inserito dall'utente
			username.item(0).setTextContent("usernameOttenutoDallaEditText");
			
			// ottengo la lista di tutti gli elementi "username"
			password = doc.getElementsByTagName("password"); 						
			// prendo il primo elemento e modifico il testo in base al valore inserito dall'utente
			password.item(0).setTextContent("passwordOttenutaDallaEditText");
		}*/

	}
}
