package apputenti;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class AppUtenti {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		
		InputStreamReader input = new InputStreamReader(System.in);
		BufferedReader tastiera = new BufferedReader(input);
		
		Connessione conn = new Connessione("172.16.102.132", 3333);
		//Connessione conn = new Connessione("172.22.108.108", 3333);
		//Connessione conn = new Connessione("127.0.0.1", 3333);
		Document doc = conn.toDOCObject("messaggio.xml");
		
		NodeList nodelist;
		
	    // ottengo la lista di tutti gli elementi "username"
		nodelist = doc.getElementsByTagName("tipo"); 
		
		// prendo il primo elemento e modifico il testo in base al valore scelto dall'utente
		nodelist.item(0).setTextContent("user");
		//nodelist.item(0).setTextContent("transport");
		
		conn.sendMessage(doc); // invio tipo di utente
		String msgRicevuto = conn.readMessage(); // ricevo "Connected"
		System.out.println("Risposta: " + msgRicevuto);
		
		msgRicevuto = conn.readMessage(); // ricevo la lista dei trasporti
		Document doc2 = Connessione.convertStringToDocument(msgRicevuto);
		System.out.println("Risposta: " + msgRicevuto);
		
		conn.sendMessage(conn.toDOCObject("mezzo.xml")); // invio mezzo desiderato
		String msgDebug = tastiera.readLine();
		conn.sendMessage(msgDebug);
		
		/*msgRicevuto = conn.readMessage();
		Document doc3 = Connessione.convertStringToDocument(msgRicevuto);
		System.out.println("Risposta: " + msgRicevuto);*/
		
		conn.closeConn(); // chiudo la connessione
	}

}
