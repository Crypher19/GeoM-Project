package apptrasporti;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


public class AppTrasporti {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException, InterruptedException {
		
		InputStreamReader input = new InputStreamReader(System.in);
		BufferedReader tastiera = new BufferedReader(input);
		
		//Connessione conn = new Connessione("172.16.102.132", 3333);
		Connessione conn = new Connessione("172.22.108.108", 3333);
		//Connessione conn = new Connessione("127.0.0.1", 3333);
		Document doc = conn.toDOCObject("messaggio.xml");
		
		NodeList nodelist;
		
	    // ottengo la lista di tutti gli elementi "username"
		nodelist = doc.getElementsByTagName("tipo"); 
		
		// prendo il primo elemento e modifico il testo in base al valore scelto dall'utente
		nodelist.item(0).setTextContent("transport");
		
		conn.sendMessage(doc); // invio tipo di utente
		String msgRicevuto = conn.readMessage(); // ricevo messaggio di conferma
		System.out.println("Risposta: " + msgRicevuto);
		
		/* 
		 * AGGIUNGERE CONTROLLO SUL MESSAGGIO DI CONFERMA (OK o altro)
		 */
		
		
		
		// Autenticazione
		Document doc4 = conn.toDOCObject("autenticazione.xml");
		NodeList username, password;
		
	    // ottengo la lista di tutti gli elementi "username"
		username = doc4.getElementsByTagName("username"); 		
		// prendo il primo elemento e modifico il testo in base al valore inserito dall'utente
		username.item(0).setTextContent("test");
		
		// ottengo la lista di tutti gli elementi "username"
		password = doc4.getElementsByTagName("password"); 						
		// prendo il primo elemento e modifico il testo in base al valore inserito dall'utente
		password.item(0).setTextContent("test");
		
		// invio le credenziali
		conn.sendMessage(doc4);
		
		// ricevo un messaggio di conferma
		msgRicevuto = conn.readMessage();
		Document docACK = Connessione.convertStringToDocument(msgRicevuto);
		System.out.println("Risposta: " + msgRicevuto);
		
		
		// ricevo la lista dei trasporti
		msgRicevuto = conn.readMessage(); // ricevo la lista dei trasporti
		Document doc2 = Connessione.convertStringToDocument(msgRicevuto);
		System.out.println("Risposta: " + msgRicevuto);
		
		// Invio mezzo
		Document doc5 = conn.toDOCObject("mezzo.xml");
		conn.sendMessage(doc5);	
		msgRicevuto = conn.readMessage();
		System.out.println("Risposta: " + msgRicevuto);
		
		
		// Invio la mia posizione
		Document doc6 = conn.toDOCObject("posizione.xml");
		NodeList coordX = doc6.getElementsByTagName("coordX"); 		
		NodeList coordY = doc6.getElementsByTagName("coordY");
		
		int i = 0;
		
		while (i < 3) {
		    // ottengo la lista di tutti gli elementi "coordX"
			// prendo il primo elemento e modifico il testo
			coordX.item(0).setTextContent("56.565156" + i);
			
			// ottengo la lista di tutti gli elementi "coordY"
			// prendo il primo elemento e modifico il testo
			coordY.item(0).setTextContent("55.142142" + i);
			conn.sendMessage(doc6);
			Thread.sleep(5000); // rallento l'invio
			//System.outprintln("inviato:" + i);
			i++;
		}
		conn.sendMessage(conn.getDOMResponse("END"));
		System.out.println("Risposta: " + msgRicevuto);
		conn.closeConn();
	}

}
