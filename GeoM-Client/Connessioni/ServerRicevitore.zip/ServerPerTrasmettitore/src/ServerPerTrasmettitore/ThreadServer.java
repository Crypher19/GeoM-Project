package ServerPerTrasmettitore;
import java.net.Socket;
import java.io.*;

public class ThreadServer extends Thread{
	InputStreamReader inp = new InputStreamReader(System.in);
	BufferedReader tastiera = new BufferedReader(inp);
	private Socket connessione;
	// stream per gestire il flusso in input
	private InputStreamReader in;
	private BufferedReader sIN;
	// stream per gestire il flusso in output
	private OutputStream out;
	private PrintWriter sOUT;

	private String recived;
	private String sent;

	private XMLReader reader;

	public ThreadServer(Socket connection){
		this.connessione = connection;

		try {
			in = new InputStreamReader(connessione.getInputStream());
			sIN = new BufferedReader(in);
			out = connessione.getOutputStream();
			sOUT = new PrintWriter(out);
		} catch (IOException e) {
			e.printStackTrace();
		}

		reader = new XMLReader();

		recived = null;
		sent = null;
	}

	@Override
	public void run(){
		try {
			
			//output su console
			System.out.println("MESSAGGIO INVIATO:\n" + sent);
			
			recived = sIN.toString();
			
			System.out.println(reader.getElement(recived, "latitudine"));
			System.out.println(reader.getElement(recived, "longitudine"));
			System.out.println();
			//chiusura connessione
			sIN.close();
			sOUT.close();
			connessione.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
