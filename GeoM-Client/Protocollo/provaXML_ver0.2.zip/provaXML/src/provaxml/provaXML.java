package provaxml;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class provaXML {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		
		Connessione conn = new Connessione();
		Document doc = conn.toDOCObject("messaggio.xml");
		
		NodeList nodelist;
		
	    // ottengo la lista di tutti gli elementi "username"
		nodelist = doc.getElementsByTagName("tipo"); 
		
		// prendo il primo elemento e modifico il testo in base al valore scelto dall'utente
		nodelist.item(0).setTextContent("transport");
		
		conn.sendMessage(doc);
		System.out.println(conn.readMessage());
		
		/*// legge messaggio server
		doc = (Document)sIN.readObject(); // ottengo l'oggetto dalla socket
		nodelist = doc.getElementsByTagName("messaggio");
		String ris = nodelist.item(0).getTextContent();
		System.out.print("Ricezione: " + ris);*/

	}
}
