package provaxml;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class provaXML {
	public static void main(String[] args) {
		//String server = "127.0.0.1";
		String server = "172.16.102.132";
		int porta = 3333;
		
		// flusso in uscita su socket
		OutputStream out;
		PrintWriter sOUT;
		
		// flusso in ingresso su socket
		InputStreamReader in;
		BufferedReader sIN;

		
		Socket connessione;
		NodeList nodelist;
		
		try {
			connessione = new Socket(server, porta);
			
			out = connessione.getOutputStream();
			sOUT = new PrintWriter(out);
			
			in = new InputStreamReader(connessione.getInputStream());
			sIN = new BufferedReader(in);
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setValidating(false); // non controllo un eventuale DTD associato
			Document doc = factory.newDocumentBuilder().parse(new File("utente.xml")); // ottengo il documento XML
			
			nodelist = doc.getElementsByTagName("tipo"); // ottengo la lista di tutti gli elementi "username"
			nodelist.item(0).setTextContent("transport"); // prendo il primo elemento e modifico il testo in
																	// base al valore scelto dall'utente
			
			
						
			// invio messaggio al server
			String msg = convertDocumentToString(doc);
			System.out.println(msg);
			sOUT.println(msg);
			sOUT.flush();
			
			/*// legge messaggio server
			doc = (Document)sIN.readObject(); // ottengo l'oggetto dalla socket
			nodelist = doc.getElementsByTagName("messaggio");
			String ris = nodelist.item(0).getTextContent();
			System.out.print("Ricezione: " + ris);*/
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} /*catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} */catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
         
        return null;
    }
 
    private static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try 
        {  
            builder = factory.newDocumentBuilder();  
            Document doc = builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
            return doc;
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;
    }
}
