package com.example.mattia.geom;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import classes.PTListAdapter;
import classes.PublicTransport;

public class ChoosePTActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_pt);

        ArrayList<PublicTransport> PTList= new ArrayList();
        PTList.add(new PublicTransport("Treno", "Include Trennord, Trenitalia e Italo", R.drawable.ic_material_railway_black));
        PTList.add(new PublicTransport("Bus", "Include ASF, Urbani e Internurbani", R.drawable.ic_material_buss_black));

        //list of Public Trnsport objects
        ListView lv = (ListView) findViewById(R.id.listview);
        lv.setAdapter(new PTListAdapter(ChoosePTActivity.this, R.layout.pt_list_layout, PTList));

    }
}
