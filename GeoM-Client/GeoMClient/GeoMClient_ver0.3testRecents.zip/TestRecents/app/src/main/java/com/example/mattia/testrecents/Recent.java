package com.example.mattia.testrecents;

/**
 * Created by Mattia on 10/02/2016.
 */
public class Recent {
    private String pt_type;
    private String pt_line;

    public Recent(String pt_type, String pt_line){
        this.pt_type = pt_type;
        this.pt_line = pt_line;
    }

    public String getPt_type(){
        return pt_type;
    }

    public String getPt_line(){
        return pt_line;
    }
}
