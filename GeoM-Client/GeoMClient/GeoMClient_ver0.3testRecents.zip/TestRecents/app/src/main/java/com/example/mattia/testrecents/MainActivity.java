package com.example.mattia.testrecents;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    MyFile f = new MyFile();
    EditText edit_type;
    EditText edit_line;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit_type = (EditText) findViewById(R.id.edit_type);
        edit_line = (EditText) findViewById(R.id.edit_line);

        Button btnCreaRecente = (Button) findViewById(R.id.recent_button);
        btnCreaRecente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String type = edit_type.getText().toString();
                String line = edit_line.getText().toString();
                if (f.checkFolderAndFile() > -1) {//controllo ok
                    if(f.newRecent(new Recent(type, line)) > -1){//aggiungo recent
                        Toast.makeText(MainActivity.this, "recente salvato", Toast.LENGTH_SHORT).show();
                    } else{//erorre
                        Toast.makeText(MainActivity.this, "erorre recente gia presente", Toast.LENGTH_SHORT).show();
                    }
                } else{//errore
                    Toast.makeText(MainActivity.this, "errore nel controllo file e cartella", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
