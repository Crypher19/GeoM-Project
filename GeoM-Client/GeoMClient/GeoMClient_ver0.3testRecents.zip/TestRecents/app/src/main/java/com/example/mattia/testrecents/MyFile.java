package com.example.mattia.testrecents;

import android.os.Environment;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * Created by Mattia on 09/02/2016.
 */
public class MyFile {
    private String folderName;
    private String folderPath;
    private String fileName;
    private String filePath;

    public MyFile(){
        folderPath = Environment.getExternalStorageDirectory().toString();
        folderName = "GeoM";
        filePath = folderPath + File.separator + folderName;
        fileName = "recents.xml";
    }

    public MyFile(String folderPath, String folderName, String filePath, String fileName){
        this.folderPath = folderPath;
        this.folderName = folderName;
        this.filePath = filePath;
        this.fileName = fileName;
    }

    private int add(Document doc, Element root, Recent pt){
        //recent
        Element recent = doc.createElement("recent");
        root.appendChild(recent);

        //pt_type
        Element pt_type = doc.createElement("pt_type");
        pt_type.appendChild(doc.createTextNode(pt.getPt_type()));
        recent.appendChild(pt_type);

        //pt_line
        Element pt_line = doc.createElement("pt_line");
        pt_line.appendChild(doc.createTextNode(pt.getPt_line()));
        recent.appendChild(pt_line);

        return toFile(doc);
    }

    public int folderExistsAndNotEmpty(String folderPath, String folderName){
        File folder = new File(folderPath + File.separator + folderName);

        if(folder.exists()) {
            File[] children = folder.listFiles();
            if(children.length > 0) return 1; //cartella con file
            return 0; //cartella vuota
        }

        return -1; //cartella inesistente
    }

    public int checkFolderAndFile(){
        File folder = new File(folderPath + File.separator + folderName);
        try {
            if (folderExistsAndNotEmpty(folderPath, folderName) > -1) { //cartella esistente
                if(fileExistsAndNotEmpty(filePath, fileName) == -1) { //file inesistente
                    new File(filePath + File.separator + fileName).createNewFile();
                }
            } else{ //cartella inesistente (creo file e cartella)
                folder.mkdir();
                new File(filePath + File.separator + fileName).createNewFile();
            }
            return 0;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1; //errore
    }

    public int fileExistsAndNotEmpty(String filePath, String fileName){
        BufferedReader br;

        try {
            if (new File(filePath + File.separator + fileName).exists()) {
                br = new BufferedReader(new FileReader(filePath + File.separator + fileName));
                if (br.readLine() != null) {
                    br.close();
                    return 1; //file pieno
                }
                br.close();
                return 0; //file vuoto
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1; //file inesistente
    }

    private String getValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = (Node) nodeList.item(0);
        return node.getNodeValue();
    }

    private int isDuplicate(Recent recent){
        List<Recent> rList = toRecentsList(this.filePath, this.fileName);

        for(int i = 0; i < rList.size(); i++){
            if(recent.getPt_type().equals(rList.get(i).getPt_type())
                    &&recent.getPt_line().equals(rList.get(i).getPt_line())) return -1; //duplicato
        }
        return 0;//non duplicato
    }

    public int newRecent(Recent recent){
        try {
            if(folderExistsAndNotEmpty(this.folderPath, this.folderName) > -1){//cartella ok
                int i;
                if((i = fileExistsAndNotEmpty(this.filePath, this.fileName)) == 0){//file vuoto
                    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

                    Element root = doc.createElement("recents");
                    doc.appendChild(root);

                    return add(doc, root, recent);
                } else if(i == 1) {//file pieno
                    if(isDuplicate(recent) == 0){//se non ho gia un recente salvato

                        Document doc = toDocument(this.filePath, this.fileName);
                        Element root = doc.getDocumentElement();

                        return add(doc, root, recent);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int toFile(Document doc){
        try {
            //scrivo il contenuto nel file xml
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); //indento il file
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filePath + File.separator + fileName));

            //trasformo il documento
            transformer.transform(source, result);

            return 0;//salvato
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;//erorre
    }

    private Document toDocument(String filePath, String fileName){
        try {
            File xmlFile = new File(filePath + File.separator + fileName);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            return doc;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private List<Recent> toRecentsList(String filePath, String fileName){
        try {
            Document doc = toDocument(filePath, fileName);

            NodeList nList = doc.getElementsByTagName("recent");
            List<Recent> rList = new ArrayList<>();

            for(int i = 0; i < nList.getLength(); i++){
                Node node = nList.item(i);//ottengo il nodo

                if (node.getNodeType() == Node.ELEMENT_NODE){
                    Element element = (Element) node;//ottengo l'elemento nel nodo

                    //aggiungo un nuovo recent
                    rList.add(new Recent(
                            getValue("pt_type", element),
                            getValue("pt_line", element)));
                }
            }
            return rList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
