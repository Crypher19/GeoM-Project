package com.example.mattia.geom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import classes.Bus;
import classes.MyFile;
import classes.Recent;
import classes.layout_classes.BusListAdapter;

public class ChooseBusActivity extends AppCompatActivity {

    Bus b;
    Recent r;
    MyFile f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_bus);

        f = new MyFile();

        ArrayList<Bus> BusList= new ArrayList();
        BusList.add(new Bus("C-80", "Mariano Comense"));
        BusList.add(new Bus("C-81", "Cantu"));

        //list of Bus objects
        ListView lv = (ListView) findViewById(R.id.bus_listview);
        lv.setAdapter(new BusListAdapter(ChooseBusActivity.this, R.layout.bus_train_list_layout, BusList));

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, final View components, int pos, long id) {
                b = (Bus) adapter.getItemAtPosition(pos);
                r = new Recent(b);//creo l'oggetto recente basato su Bus

                if(f.addRecent(r) > -1){
                    Toast.makeText(ChooseBusActivity.this, "Recente salvato", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(ChooseBusActivity.this, " ERRORE con il recente o recente duplicato", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
