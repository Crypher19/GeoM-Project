package com.example.mattia.geom;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import classes.layout_classes.PTListAdapter;
import classes.PublicTransport;

public class ChoosePTActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_pt);

        ArrayList<PublicTransport> PTList= new ArrayList();
        PTList.add(new PublicTransport("Treno", "Include Trennord, Trenitalia e Italo", R.drawable.ic_material_railway_black));
        PTList.add(new PublicTransport("Bus", "Include ASF, Urbani e Internurbani", R.drawable.ic_material_buss_black));

        //list of Public Trnsport objects
        ListView lv = (ListView) findViewById(R.id.listview);
        lv.setAdapter(new PTListAdapter(ChoosePTActivity.this, R.layout.pt_list_layout, PTList));

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> adapter, final View components, int pos, long id){

                 PublicTransport pt = (PublicTransport) adapter.getItemAtPosition(pos);
                 String pt_name = pt.getPTType();
                 Intent i;
                 if(pt_name.equals("Treno")){
                     i = new Intent(ChoosePTActivity.this, ChooseTrainActivity.class);
                 } else{
                     i = new Intent(ChoosePTActivity.this, ChooseBusActivity.class);
                 }
                 startActivity(i);
             }
        });
    }
}
