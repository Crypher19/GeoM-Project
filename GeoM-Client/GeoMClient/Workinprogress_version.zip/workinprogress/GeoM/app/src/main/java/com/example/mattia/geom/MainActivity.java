package com.example.mattia.geom;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import classes.MyFile;
import classes.Recent;
import classes.layout_classes.RecentListAdapter;
import classes.layout_classes.RecentsFragment;
import classes.layout_classes.ViewPagerAdapter;

public class MainActivity extends AppCompatActivity {
    private FloatingActionButton fab;
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    MyFile f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        f = new MyFile();

        if(f.checkFolderAndFile() > -1){//controlli su cartella e file
            List<Recent> recentsList = f.getRecentsList();

            if(recentsList.size() > 0){//controllo se ci sono recenti
                ListView lv = (ListView) findViewById(R.id.main_recent_listview);
                lv.setAdapter(new RecentListAdapter(MainActivity.this, R.layout.recent_layout, (ArrayList)recentsList));
            }
        } else{
            Toast.makeText(MainActivity.this, "ERROR while checking folder and file", Toast.LENGTH_LONG).show();
        }

        //material view
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        //floating action button
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Click action
                Intent intent = new Intent(MainActivity.this, ChoosePTActivity.class);
                startActivity(intent);
            }
        });
    }

    //material view implemented method
    public void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new RecentsFragment(), "Recenti");
        viewPager.setAdapter(adapter);
    }
}