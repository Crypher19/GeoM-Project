package com.example.mattia.geom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import classes.MyFile;
import classes.Recent;
import classes.Train;
import classes.layout_classes.TrainListAdapter;

public class ChooseTrainActivity extends AppCompatActivity {

    Train t;
    Recent r;
    MyFile f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_train);

        f = new MyFile();

        ArrayList<Train> TrainList= new ArrayList();
        TrainList.add(new Train("T01", "Milano-Asso"));
        TrainList.add(new Train("T02", "Milano-Venezia"));

        //list of Bus objects
        ListView lv = (ListView) findViewById(R.id.train_listview);
        lv.setAdapter(new TrainListAdapter(ChooseTrainActivity.this, R.layout.bus_train_list_layout, TrainList));

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, final View components, int pos, long id) {
                t = (Train) adapter.getItemAtPosition(pos);
                r = new Recent(t);//creo l'oggetto recente basato su Train

                if(f.addRecent(r) > -1){
                    Toast.makeText(ChooseTrainActivity.this, "Recente salvato", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(ChooseTrainActivity.this, " ERRORE con il recente o recente duplicato", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
