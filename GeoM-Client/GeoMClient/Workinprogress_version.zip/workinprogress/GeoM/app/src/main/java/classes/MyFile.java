package classes;

import android.os.Environment;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Exception;import java.lang.String;import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * Created by Mattia on 09/02/2016.
 */
public class MyFile {
    private String folderName;
    private String folderPath;
    private String fileName;
    private String filePath;

    public MyFile(){
        folderPath = Environment.getExternalStorageDirectory().toString();
        folderName = "GeoM";
        filePath = folderPath + File.separator + folderName;
        fileName = "recents.xml";

        checkFolderAndFile();
    }

    public MyFile(String folderPath, String folderName, String filePath, String fileName){
        this.folderPath = folderPath;
        this.folderName = folderName;
        this.filePath = filePath;
        this.fileName = fileName;

        checkFolderAndFile();
    }

    private int add(Document doc, Element root, Recent r){
        //recent
        Element recent = doc.createElement("recent");
        root.appendChild(recent);

        //pt_type
        Element pt_type = doc.createElement("pt_type");
        pt_type.appendChild(doc.createTextNode(r.getPt_type()));
        recent.appendChild(pt_type);

        //pt_name
        Element pt_name = doc.createElement("pt_name");
        pt_name.appendChild(doc.createTextNode(r.getPt_name()));
        recent.appendChild(pt_name);

        //pt_name
        Element pt_city = doc.createElement("pt_city");
        pt_city.appendChild(doc.createTextNode(r.getPt_city()));
        recent.appendChild(pt_city);

        //pt_image_id
        Element pt_image_id = doc.createElement("pt_image_id");
        pt_image_id.appendChild(doc.createTextNode(Integer.toString(r.getPt_image_id())));
        recent.appendChild(pt_image_id);

        return toFile(doc);
    }

    private int checkFolderAndFile(){
        File folder = new File(folderPath + File.separator + folderName);
        try {
            if (folderExistsAndNotEmpty(folderPath, folderName) > -1) { //cartella esistente
                if(fileExistsAndNotEmpty(filePath, fileName) == -1) { //file inesistente
                    new File(filePath + File.separator + fileName).createNewFile();
                }
            } else{ //cartella inesistente (creo file e cartella)
                folder.mkdir();
                new File(filePath + File.separator + fileName).createNewFile();
            }
            return 0;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1; //errore
    }

    public int fileExistsAndNotEmpty(String filePath, String fileName){
        BufferedReader br;

        try {
            if (new File(filePath + File.separator + fileName).exists()) {
                br = new BufferedReader(new FileReader(filePath + File.separator + fileName));
                if (br.readLine() != null) {
                    br.close();
                    return 1; //file pieno
                }
                br.close();
                return 0; //file vuoto
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return -1; //file inesistente
    }

    public int folderExistsAndNotEmpty(String folderPath, String folderName){
        File folder = new File(folderPath + File.separator + folderName);

        if(folder.exists()) {
            File[] children = folder.listFiles();
            if(children.length > 0) return 1; //cartella con file
            return 0; //cartella vuota
        }

        return -1; //cartella inesistente
    }

    private String getValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = (Node) nodeList.item(0);
        return node.getNodeValue();
    }

    private int isDuplicate(Recent recent){
        List<Recent> rList = toRecentsList(this.filePath, this.fileName);

        for(int i = 0; i < rList.size(); i++){
            if(recent.getPt_type().equals(rList.get(i).getPt_type())
                    && recent.getPt_name().equals(rList.get(i).getPt_name())
                    && recent.getPt_city().equals(rList.get(i).getPt_city())
                    && recent.getPt_image_id() == rList.get(i).getPt_image_id()) return -1; //duplicato
        }
        return 0;//non duplicato
    }

    public int addRecent(Recent recent){
        try {
            if(folderExistsAndNotEmpty(this.folderPath, this.folderName) > -1){//cartella ok
                int i;
                if((i = fileExistsAndNotEmpty(this.filePath, this.fileName)) == 0){//file vuoto
                    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

                    Element root = doc.createElement("recents");
                    doc.appendChild(root);

                    return add(doc, root, recent);
                } else if(i == 1) {//file pieno
                    if(isDuplicate(recent) == 0){//non ho un doppione

                        Document doc = toDocument(this.filePath, this.fileName);
                        Element root = doc.getDocumentElement();

                        return add(doc, root, recent);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int toFile(Document doc){
        try {
            //scrivo il contenuto nel file xml
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); //indento il file
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filePath + File.separator + fileName));

            //trasformo il documento
            transformer.transform(source, result);

            return 0;//salvato
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;//erorre
    }

    private Document toDocument(String filePath, String fileName){
        try {
            File xmlFile = new File(filePath + File.separator + fileName);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            return doc;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private List<Recent> toRecentsList(String filePath, String fileName){
        try {
            Document doc = toDocument(filePath, fileName);

            NodeList nList = doc.getElementsByTagName("recent");
            List<Recent> rList = new ArrayList<>();

            for(int i = 0; i < nList.getLength(); i++){
                Node node = nList.item(i);//ottengo il nodo

                if (node.getNodeType() == Node.ELEMENT_NODE){
                    Element element = (Element) node;//ottengo l'elemento nel nodo

                    //aggiungo un nuovo recent
                    rList.add(new Recent(
                            getValue("pt_type", element),
                            getValue("pt_name", element),
                            getValue("pt_city", element),
                            Integer.parseInt(getValue("pt_image_id", element))));
                }
            }
            return rList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
