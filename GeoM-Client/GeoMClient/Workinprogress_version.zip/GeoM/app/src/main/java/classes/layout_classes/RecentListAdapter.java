package classes.layout_classes;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mattia.geom.R;

import java.util.ArrayList;

import classes.PublicTransport;
import classes.Recent;

/**
 * Created by Mattia on 05/02/2016.
 */
//list for public transport elements
public class RecentListAdapter extends ArrayAdapter<Recent> {
    private Activity activity;
    private ArrayList<Recent> recentsList;
    private LayoutInflater inflater = null;

    public RecentListAdapter(Activity activity, int textViewResourceId, ArrayList<Recent> recentsList) {
        super(activity, textViewResourceId, recentsList);
        try {
            this.activity = activity;
            this.recentsList = recentsList;

            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getCount() {
        return recentsList.size();
    }

    public Recent getItem(Recent position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder {
        public ImageView recent_image_id;
        public TextView recent_type;
        public TextView recent_name;

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        final ViewHolder holder;
        try {
            if (convertView == null) {
                vi = inflater.inflate(R.layout.recent_layout, null);
                holder = new ViewHolder();

                holder.recent_image_id = (ImageView) vi.findViewById(R.id.recent_image);
                holder.recent_type = (TextView) vi.findViewById(R.id.recent_type);
                holder.recent_name = (TextView) vi.findViewById(R.id.recent_name);

                vi.setTag(holder);
            } else {
                holder = (ViewHolder) vi.getTag();
            }

            holder.recent_image_id.setImageResource(recentsList.get(position).getPt_image_id());
            holder.recent_type.setText(recentsList.get(position).getPt_type());
            holder.recent_name.setText(recentsList.get(position).getPt_name());


        } catch (Exception e) {
            e.printStackTrace();
        }
        return vi;
    }
}
