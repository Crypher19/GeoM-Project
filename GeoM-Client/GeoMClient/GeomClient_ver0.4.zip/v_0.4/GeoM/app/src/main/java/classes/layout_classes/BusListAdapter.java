package classes.layout_classes;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mattia.geom.R;

import java.util.ArrayList;

import classes.Bus;

/**
 * Created by Mattia on 14/02/2016.
 */
public class BusListAdapter extends ArrayAdapter<Bus> {
    private Activity activity;
    private ArrayList<Bus> BusList;
    private LayoutInflater inflater = null;

    public BusListAdapter(Activity activity, int textViewResourceId, ArrayList<Bus> BusList) {
        super(activity, textViewResourceId, BusList);
        try {
            this.activity = activity;
            this.BusList = BusList;

            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getCount() {
        return BusList.size();
    }

    public Bus getItem(Bus position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder {
        public TextView BusName;
        public TextView BusCity;

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        final ViewHolder holder;
        try {
            if (convertView == null) {
                vi = inflater.inflate(R.layout.bus_train_list_layout, null);
                holder = new ViewHolder();

                holder.BusName = (TextView) vi.findViewById(R.id.bus_train_name);
                holder.BusCity = (TextView) vi.findViewById(R.id.bus_train_city);

                vi.setTag(holder);
            } else {
                holder = (ViewHolder) vi.getTag();
            }

            holder.BusName.setText(BusList.get(position).getPTName());
            holder.BusCity.setText(BusList.get(position).getPTCity());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return vi;
    }
}
