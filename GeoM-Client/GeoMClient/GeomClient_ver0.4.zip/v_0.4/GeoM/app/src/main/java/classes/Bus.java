package classes;

import com.example.mattia.geom.R;

import static com.example.mattia.geom.R.drawable.ic_material_no_image_black;

/**
 * Created by Mattia on 14/02/2016.
 */
public class Bus extends PublicTransport {

    private String PTName;
    private String PTCity;

    public Bus(String PTName, String PTCity){
        super("Bus", "Include ASF, Urbani e Internurbani", R.drawable.ic_material_buss_black);
        setPTName(PTName);
        setPTCity(PTCity);
    }

    public String getPTName() {
        return PTName;
    }

    public void setPTName(String PTName) {
        this.PTName = PTName;
    }

    public String getPTCity() {
        return PTCity;
    }

    public void setPTCity(String PTCity) {
        this.PTCity = PTCity;
    }
}
