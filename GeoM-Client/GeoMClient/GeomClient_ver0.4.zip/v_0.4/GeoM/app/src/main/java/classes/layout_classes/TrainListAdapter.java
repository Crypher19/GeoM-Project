package classes.layout_classes;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mattia.geom.R;

import java.util.ArrayList;

import classes.Train;

/**
 * Created by Mattia on 14/02/2016.
 */
public class TrainListAdapter extends ArrayAdapter<Train> {
    private Activity activity;
    private ArrayList<Train> TrainList;
    private LayoutInflater inflater = null;

    public TrainListAdapter(Activity activity, int textViewResourceId, ArrayList<Train> TrainList) {
        super(activity, textViewResourceId, TrainList);
        try {
            this.activity = activity;
            this.TrainList = TrainList;

            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getCount() {
        return TrainList.size();
    }

    public Train getItem(Train position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder {
        public TextView TainName;
        public TextView TrainCity;

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        final ViewHolder holder;
        try {
            if (convertView == null) {
                vi = inflater.inflate(R.layout.bus_train_list_layout, null);
                holder = new ViewHolder();

                holder.TainName = (TextView) vi.findViewById(R.id.bus_train_name);
                holder.TrainCity = (TextView) vi.findViewById(R.id.bus_train_city);

                vi.setTag(holder);
            } else {
                holder = (ViewHolder) vi.getTag();
            }

            holder.TainName.setText(TrainList.get(position).getPTName());
            holder.TrainCity.setText(TrainList.get(position).getPTCity());


        } catch (Exception e) {
            e.printStackTrace();
        }
        return vi;
    }
}