package com.example.mattia.geom;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ChoosePTActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_pt);

        List<PublicTransport> PTList= new ArrayList();

        ListView listView1 = (ListView) findViewById(R.id.pt_listview);

        PTAdapter adapter;

        PTList.add(new PublicTransport("Treno", "Include Trennord, Trenitalia e Italo", R.drawable.ic_material_railway_black));
        PTList.add(new PublicTransport("Bus", "Include ASF, Urbani e Internurbani", R.drawable.ic_material_buss_black));

        adapter= new PTAdapter (ChoosePTActivity.this, R.layout.pt_layout, PTList);
        listView1.setAdapter(adapter);
    }
}

class PTAdapter extends ArrayAdapter<PublicTransport> {
    private Activity activity;
    private ArrayList<PublicTransport> PTArray;
    private static LayoutInflater inflater = null;

    public PTAdapter (Activity activity, int textViewResourceId,ArrayList<PublicTransport> PTArray) {
        super(activity, textViewResourceId, PTArray);
        try {
            this.activity = activity;
            this.PTArray = PTArray;

            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        } catch (Exception e) {

        }
    }

    public int getCount() {
        return PTArray.size();
    }

    public PublicTransport getItem(PublicTransport position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    //sono arrivato quieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
    public static class ViewHolder {
        public TextView PTName;
        public TextView PTDescription;
        public ImageView PTImageID;

    }

    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        ViewHolder holder;
        try{
            if (convertView == null) {
                vi = inflater.inflate(R.layout.product_layout, null);
                holder = new ViewHolder();

                holder.product_id = (TextView) vi.findViewById(R.id.product_id);
                holder.product_name = (TextView) vi.findViewById(R.id.product_name);
                holder.product_price = (TextView) vi.findViewById(R.id.product_price);

                vi.setTag(holder);
            } else {
                holder = (ViewHolder) vi.getTag();
            }



            holder.product_id.setText(productsArray.get(position).getStrId());
            holder.product_name.setText(productsArray.get(position).getName());
            holder.product_price.setText(productsArray.get(position).getStrPrice());

        } catch (Exception e) {
            System.out.println("getView exception: setText method accepts only string values");
        }
        return vi;
    }
