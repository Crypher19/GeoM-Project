package com.example.mattia.geom;

import static com.example.mattia.geom.R.drawable.ic_material_no_image_black;

/**
 * Created by Mattia on 02/02/2016.
 */
public class PublicTransport {
    private String PTName;
    private String PTDescription;
    private int PTPhotoID;

    public PublicTransport(String PTName, String PTDescription, int PTPhotoID){
        this.PTName=PTName;
        this.PTDescription=PTDescription;
        this.PTPhotoID=PTPhotoID;
    }

    //PT without any image
    public PublicTransport(String PTName, String PTDescription){
        this.PTName=PTName;
        this.PTDescription=PTDescription;
        this.PTPhotoID= ic_material_no_image_black;
    }

    public String getPTName(){
        return this.PTName;
    }

    public String getPTDescription(){
        return this.PTDescription;
    }

    public int getPTPhotoID(){
        return PTPhotoID;
    }

    public void setPTName(String PTName){
        this.PTName=PTName;
    }

    public void setPTDescription(String PTDescription){
        this.PTDescription=PTDescription;
    }

    public void setPTPhotoID(int PTPhotoID){
        this.PTPhotoID = PTPhotoID;
    }
}
